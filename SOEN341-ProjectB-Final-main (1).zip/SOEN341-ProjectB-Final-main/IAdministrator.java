public interface IAdministrator
{
    boolean isthereoption = true;
    String option = null;
    String  file = null;

}
