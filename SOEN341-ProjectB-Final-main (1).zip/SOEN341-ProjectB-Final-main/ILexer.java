import java.util.List;



public interface ILexer 
{
	
	
	
}