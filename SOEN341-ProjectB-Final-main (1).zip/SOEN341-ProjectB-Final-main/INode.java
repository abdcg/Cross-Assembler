
public interface INode {

}