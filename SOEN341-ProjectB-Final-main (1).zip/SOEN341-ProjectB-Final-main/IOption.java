public interface IOption {
    boolean getVerbose();
    void printOption();
}
