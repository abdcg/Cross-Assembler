
public interface IReader {

}
