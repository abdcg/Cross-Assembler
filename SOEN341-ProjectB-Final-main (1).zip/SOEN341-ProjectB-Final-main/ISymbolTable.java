public interface ISymbolTable 
{
        void addSymbol(String name, String type, int address);
        void populate(String name); 
        
        

}