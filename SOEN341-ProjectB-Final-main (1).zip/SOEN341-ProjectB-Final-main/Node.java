public abstract class Node
{

}